import React from 'react';
import { useExplorer } from '../../store/explorerStore';
import type { WindowState } from '../../store/explorerStore';
import { ExplorerPane } from './ExplorerPane';
import { Icon } from './Icons';

const TASKBAR_H = 48;
const MIN_W = 420;
const MIN_H = 280;

// Only one window gesture (drag/resize/splitter) can be active at a time, so it
// lives at module scope. This keeps the gesture handlers off React refs entirely.
type Gesture =
  | { mode: 'move'; winId: number; winW: number; startX: number; startY: number; ox: number; oy: number }
  | {
      mode: 'resize';
      winId: number;
      dir: string;
      startX: number;
      startY: number;
      ox: number;
      oy: number;
      ow: number;
      oh: number;
    }
  | { mode: 'split'; winId: number; bodyLeft: number; bodyW: number };

let active: Gesture | null = null;

function onMove(e: PointerEvent) {
  const g = active;
  if (!g) return;
  const st = useExplorer.getState();
  if (g.mode === 'move') {
    const maxX = window.innerWidth;
    const maxY = window.innerHeight - TASKBAR_H;
    const x = Math.min(Math.max(g.ox + (e.clientX - g.startX), -(g.winW - 120)), maxX - 80);
    const y = Math.min(Math.max(g.oy + (e.clientY - g.startY), 0), maxY - 36);
    st.setBounds(g.winId, { x, y });
  } else if (g.mode === 'resize') {
    const dx = e.clientX - g.startX;
    const dy = e.clientY - g.startY;
    let x = g.ox;
    let y = g.oy;
    let w = g.ow;
    let h = g.oh;
    if (g.dir.includes('e')) w = Math.max(MIN_W, g.ow + dx);
    if (g.dir.includes('s')) h = Math.max(MIN_H, g.oh + dy);
    if (g.dir.includes('w')) {
      w = Math.max(MIN_W, g.ow - dx);
      x = g.ox + (g.ow - w);
    }
    if (g.dir.includes('n')) {
      h = Math.max(MIN_H, g.oh - dy);
      y = g.oy + (g.oh - h);
    }
    st.setBounds(g.winId, { x, y, w, h });
  } else {
    st.setSplitter(g.winId, (e.clientX - g.bodyLeft) / g.bodyW);
  }
}

function endGesture() {
  active = null;
  window.removeEventListener('pointermove', onMove);
  window.removeEventListener('pointerup', endGesture);
  document.body.style.userSelect = '';
  document.body.style.cursor = '';
}

function beginGesture(g: Gesture, cursor?: string) {
  active = g;
  document.body.style.userSelect = 'none';
  if (cursor) document.body.style.cursor = cursor;
  window.addEventListener('pointermove', onMove);
  window.addEventListener('pointerup', endGesture);
}

export const ExplorerWindow: React.FC<{ win: WindowState }> = ({ win }) => {
  const store = useExplorer.getState;

  if (win.minimized) return null;

  const startMove = (e: React.PointerEvent) => {
    store().focusWindow(win.id);
    if (win.maximized) return;
    beginGesture({ mode: 'move', winId: win.id, winW: win.w, startX: e.clientX, startY: e.clientY, ox: win.x, oy: win.y });
  };

  const startResize = (dir: string) => (e: React.PointerEvent) => {
    e.stopPropagation();
    store().focusWindow(win.id);
    if (win.maximized) return;
    beginGesture(
      { mode: 'resize', winId: win.id, dir, startX: e.clientX, startY: e.clientY, ox: win.x, oy: win.y, ow: win.w, oh: win.h },
      'default',
    );
  };

  const startSplit = (e: React.PointerEvent) => {
    e.stopPropagation();
    const body = e.currentTarget.parentElement;
    if (!body) return;
    const rect = body.getBoundingClientRect();
    beginGesture({ mode: 'split', winId: win.id, bodyLeft: rect.left, bodyW: rect.width }, 'col-resize');
  };

  const frameStyle: React.CSSProperties = win.maximized
    ? { left: 0, top: 0, width: '100%', height: '100%', zIndex: win.z }
    : { left: win.x, top: win.y, width: win.w, height: win.h, zIndex: win.z };

  const dual = win.layout === 'dual';
  const leftPct = dual ? `${(win.splitter * 100).toFixed(2)}%` : '100%';

  return (
    <div
      className="absolute flex flex-col rounded-xl overflow-hidden border border-ghost-border bg-ghost-bg"
      style={{ ...frameStyle, boxShadow: '0 24px 70px rgba(0,0,0,0.55)' }}
      onMouseDown={() => store().focusWindow(win.id)}
    >
      {/* Title bar */}
      <div
        onPointerDown={startMove}
        onDoubleClick={() => store().toggleMax(win.id)}
        className="gk-gesture flex items-center gap-2 h-11 px-3 shrink-0 bg-ghost-surface border-b border-ghost-border cursor-default select-none"
      >
        <div className="flex items-center gap-1.5">
          <span className="w-2.5 h-2.5 rounded-full bg-ghost-accent" />
          <span className="w-2.5 h-2.5 rounded-full bg-ghost-cyan/70" />
          <span className="w-2.5 h-2.5 rounded-full bg-ghost-green/60" />
        </div>
        <span className="text-[12px] font-medium text-ghost-text tracking-wide ml-1">{win.title}</span>
        <span className="text-[10px] text-ghost-muted ml-1 hidden sm:inline">— Ghost Key</span>
        <div className="flex-1" />
        <WinBtn title="Minimize" onClick={() => store().minimize(win.id)}>
          <Icon name="minus" size={14} />
        </WinBtn>
        <WinBtn title={win.maximized ? 'Restore' : 'Maximize'} onClick={() => store().toggleMax(win.id)}>
          <Icon name={win.maximized ? 'restore' : 'square'} size={13} />
        </WinBtn>
        <WinBtn
          title={win.layout === 'dual' ? 'Use single pane' : 'Use dual pane'}
          onClick={() => store().toggleLayout(win.id)}
          active={win.layout === 'dual'}
        >
          <Icon name="columns" size={14} />
        </WinBtn>
        <WinBtn title="Close" danger onClick={() => store().closeWindow(win.id)}>
          <Icon name="x" size={14} />
        </WinBtn>
      </div>

      {/* Dual-pane body */}
      <div className="flex-1 flex min-h-0">
        <div style={{ width: leftPct }} className={`min-w-0 ${dual ? 'border-r border-ghost-border' : ''}`}>
          <ExplorerPane winId={win.id} side="left" />
        </div>
        {dual && (
          <>
            {/* Splitter */}
            <div
              onPointerDown={startSplit}
              onDoubleClick={() => store().resetSplitter(win.id)}
              className="gk-gesture relative w-3 shrink-0 cursor-col-resize bg-ghost-border hover:bg-ghost-accent active:bg-ghost-accent transition-colors flex items-center justify-center"
              title="Drag to resize panes · double-click to balance"
            >
              <span className="pointer-events-none h-8 w-0.5 rounded-full bg-ghost-muted/50" />
            </div>
            <div style={{ width: `calc(100% - ${leftPct} - 6px)` }} className="min-w-0">
              <ExplorerPane winId={win.id} side="right" />
            </div>
          </>
        )}
      </div>

      {/* Resize handles (hidden when maximized) */}
      {!win.maximized && (
        <>
          <div onPointerDown={startResize('e')} className="gk-gesture absolute top-11 right-0 w-3 h-[calc(100%-2.75rem)] cursor-e-resize" />
          <div onPointerDown={startResize('s')} className="gk-gesture absolute bottom-0 left-0 w-full h-3 cursor-s-resize" />
          <div onPointerDown={startResize('w')} className="gk-gesture absolute top-11 left-0 w-3 h-[calc(100%-2.75rem)] cursor-w-resize" />
          <div onPointerDown={startResize('n')} className="gk-gesture absolute top-0 left-10 right-10 h-2 cursor-n-resize" />
          <div onPointerDown={startResize('se')} className="gk-gesture absolute bottom-0 right-0 w-6 h-6 cursor-se-resize" />
          <div onPointerDown={startResize('sw')} className="gk-gesture absolute bottom-0 left-0 w-6 h-6 cursor-sw-resize" />
          <div onPointerDown={startResize('ne')} className="gk-gesture absolute top-0 right-0 w-6 h-6 cursor-ne-resize" />
          <div onPointerDown={startResize('nw')} className="gk-gesture absolute top-0 left-0 w-6 h-6 cursor-nw-resize" />
        </>
      )}
    </div>
  );
};

const WinBtn: React.FC<{
  title: string;
  onClick: () => void;
  danger?: boolean;
  active?: boolean;
  children: React.ReactNode;
}> = ({ title, onClick, danger, active, children }) => (
  <button
    title={title}
    onPointerDown={(e) => e.stopPropagation()}
    onClick={(e) => {
      e.stopPropagation();
      onClick();
    }}
    className={`w-7 h-7 flex items-center justify-center rounded-md transition-colors ${
      danger ? 'hover:bg-ghost-red hover:text-white' : 'hover:bg-ghost-card hover:text-ghost-text'
    } ${active ? 'text-ghost-accent bg-ghost-accent/10' : 'text-ghost-muted'}`}
  >
    {children}
  </button>
);
